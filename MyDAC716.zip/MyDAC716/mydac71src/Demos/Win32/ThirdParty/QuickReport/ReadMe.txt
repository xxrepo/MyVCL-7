Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

Demo for QuickReport included in MyDAC was built and tested using 
Borland QuickReport Components in Delphi 5.

Lets you launch and view a QuickReport application based on MyDAC.
This demo project lets you modify the application in design-time.

IMPORTANT NOTE:
  Demo provided "as is", and there is no warranty that it is fully
  compatible with other versions of QuickReport.
