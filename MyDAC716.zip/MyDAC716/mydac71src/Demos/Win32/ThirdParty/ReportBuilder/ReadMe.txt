Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

Demo for ReportBuilder included in MyDAC was built and tested using
Report Builder Pro 9.0 for Delphi 7.

IMPORTANT NOTE:
  Demos are provided "as is", and there is no warranty that they are fully
  compatible with other versions of Report Builder Pro.