Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

Demo for IntraWeb included in MyDAC was built and tested using
IntraWeb 7.2.14 for Delphi 2005.

IMPORTANT NOTE:
  Demo is provided "as is", and there is no warranty that it is fully
  compatible with other versions of IntraWeb.