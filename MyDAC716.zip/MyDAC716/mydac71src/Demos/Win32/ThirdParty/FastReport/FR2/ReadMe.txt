Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

Demo for FastReport included in MyDAC was built and tested using
Fast Report 2.47 for Delphi 7.

IMPORTANT NOTE:
  Demo is provided "as is", and there is no warranty that it is fully
  compatible with other versions of Fast Report.