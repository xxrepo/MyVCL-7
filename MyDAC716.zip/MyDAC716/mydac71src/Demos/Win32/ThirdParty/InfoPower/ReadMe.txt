Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

This demo was built and tested using 
InfoPower 4000 Trial for Delphi 7.

To install TwwMyQuery and TwwMyTable components, compile and install 
the MyIPPack package.
The MyIPPack package requires InfoPower (ip*.dcp). To make it you need
to compile the InfoPower package (ip*.dpk).

You can recompile it under other versions by changing the Requires section
in the MyIPPack.dpk file manually.

IMPORTANT NOTE:
  This demo is provided "as is", and there is no warranty that it is fully
  compatible with other versions of InfoPower.