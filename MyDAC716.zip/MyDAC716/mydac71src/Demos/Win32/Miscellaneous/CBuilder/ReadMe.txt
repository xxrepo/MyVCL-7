Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

A general demo project about creating MyDAC-based applications with
C++Builder. Lets you execute SQL scripts and work with result sets in a
grid. This is one of two MyDAC demos for C++Builder.
