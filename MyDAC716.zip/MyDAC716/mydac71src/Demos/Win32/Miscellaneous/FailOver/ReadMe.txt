Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

Demonstrates the recommended approach for working with unstable networks.
This sample lets you perform transactions and updates in several different
modes, simulate a sudden session termination, and view what happenvs to the state of your
data when connections to the server are unexpectedly lost. Shows off
CachedUpdates, LocalMasterDetail, FetchAll, Pooling, and different Failover
modes.
