Data Access Components for MySQL
Copyright 1997-2012, Devart. All Rights Reserved
--------------------------------------------------

Demonstrates working with Embedded MySQL Server through the
TMyEmbConnection component. This demo creates a database structure,
if it does not exist, and opens a table from this database. Also
this demo shows how to process log messages of the Embedded MySQL Server.
